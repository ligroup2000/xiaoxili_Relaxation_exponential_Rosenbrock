-The program codes in this folder are to test the accuracy of RER(2,1). 

-"reference.mat" is copied from the previous folder "1.compute_reference_solution".

-Please run "main.m" directly, and it will return:
err =

   0.023254899670070   0.005716454773120   0.002526952938055   0.001417633211540


Err_order =

   2.024342115717675   2.013328884325743   2.009250945200094


Gamma_average_save =

   0.006955463522182   0.003476086324951   0.002317104741171   0.001737718217352


Gamma_average_order =

   1.000682750849700   1.000304548060161   1.000220709607047