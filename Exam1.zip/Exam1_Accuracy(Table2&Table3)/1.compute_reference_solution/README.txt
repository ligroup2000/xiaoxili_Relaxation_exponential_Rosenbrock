-The program codes in this folder are to compute the reference solution. 

-Please run "reference.m" directly, and it will return "reference.mat", which contains the reference solution 'Vn_t_c_10000' and 'Un_t_c_10000'.

-We also provide the data in the folder.