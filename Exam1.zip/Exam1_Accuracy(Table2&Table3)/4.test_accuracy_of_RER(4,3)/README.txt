-The program codes in this folder are to test the accuracy of RER(4,3). 

-"reference.mat" is copied from the previous folder "1.compute_reference_solution".

-Please run "main.m" directly, and it will return:
err =

   1.0e-06 *

   0.161089079075971   0.011063427174385   0.002255286846164   0.000727760185448


Err_order =

   3.863988419897886   3.922329241210879   3.931634878671995


Gamma_average_save =

   1.0e-06 *

   0.100528045507420   0.012514079613205   0.003702496513701   0.001560816752742


Gamma_average_order =

   3.005973950834408   3.003580405763301   3.002613525719474