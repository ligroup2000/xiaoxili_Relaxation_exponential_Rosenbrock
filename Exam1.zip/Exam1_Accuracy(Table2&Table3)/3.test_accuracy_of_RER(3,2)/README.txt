-The program codes in this folder are to test the accuracy of RER(3,2). 

-"reference.mat" is copied from the previous folder "1.compute_reference_solution".

-Please run "main.m" directly, and it will return:
err =

   1.0e-04 *

   0.967955803734544   0.121093048346399   0.035895299662636   0.015147184944109


Err_order =

   2.998825130596101   2.998908813729295   2.999115129183033


Gamma_average_save =

   1.0e-04 *

   0.475981988510006   0.118979475269649   0.052873188360891   0.029739273972403


Gamma_average_order =

   2.000194261225639   2.000306835754716   2.000221428321945