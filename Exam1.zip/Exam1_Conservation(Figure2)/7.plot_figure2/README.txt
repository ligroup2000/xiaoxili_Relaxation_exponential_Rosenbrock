-The program codes in this folder are to plot the evolutions of the energy discrepancies of the ER methods and the corresponding RER methods.

-"exprb2s1.mat" contain the energy evolutions and corresponding times of ER(2,1).

-"exprb3s2.mat" contain the energy evolutions and corresponding times of ER(3,2).

-"exprb4s3.mat" contain the energy evolutions and corresponding times of ER(4,3).

-"rexprb2s1.mat" contain the energy evolutions and corresponding times of RER(2,1). 

-"rexprb3s2.mat" contain the energy evolutions and corresponding times of RER(3,2). 

-"rexprb4s3.mat" contain the energy evolutions and corresponding times of RER(4,3)

-Please run "main.m" directly, and it will return the figure that records the evolutions of the energy discrepancies of the methods.

-We also provide the figure "energy_kg.eps" in the folder.