-The program codes in this folder are to record the energy evolution of ER(4,3) with tau=1/150. 

-Please run "exprb4s3.m" directly, and it will return "exprb4s3.mat", which contains 
--Energy4s3: the energy evolution;
--tmesh4s3: the corresponding times.

-We also provide the data in the folder.