-The program codes in this folder are to record the energy evolution of RER(4,3) with tau=1/20. 

-Please run "rexprb4s3.m" directly, and it will return "rexprb4s3.mat", which contains 
--Energyr4s3: the energy evolution;
--tmeshr4s3: the corresponding times;
--timer4s3: the CPU time.

-We also provide the data in the folder.