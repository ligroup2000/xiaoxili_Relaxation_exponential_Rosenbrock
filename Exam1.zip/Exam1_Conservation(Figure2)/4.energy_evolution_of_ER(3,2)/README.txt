-The program codes in this folder are to record the energy evolution of ER(3,2) with tau=1/300. 

-Please run "exprb3s2.m" directly, and it will return "exprb3s2.mat", which contains 
--Energy3s2: the energy evolution;
--tmesh3s2: the corresponding times.

-We also provide the data in the folder.