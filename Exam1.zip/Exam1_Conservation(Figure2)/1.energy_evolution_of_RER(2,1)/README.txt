-The program codes in this folder are to record the energy evolution of RER(2,1) with tau=1/50. 

-Please run "rexprb2s1.m" directly, and it will return "rexprb2s1.mat", which contains 
--Energyr2s1: the energy evolution;
--tmeshr2s1: the corresponding times;
--timer2s1: the CPU time.

-We also provide the data in the folder.