-The program codes in this folder are to record the energy evolution of RER(3,2) with tau=1/30. 

-Please run "rexprb3s2.m" directly, and it will return "rexprb3s2.mat", which contains 
--Energyr3s2: the energy evolution;
--tmeshr3s2: the corresponding times;
--timer3s2: the CPU time.

-We also provide the data in the folder.