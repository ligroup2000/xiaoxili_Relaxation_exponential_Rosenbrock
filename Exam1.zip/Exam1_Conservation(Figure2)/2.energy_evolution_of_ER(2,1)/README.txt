-The program codes in this folder are to record the energy evolution of ER(2,1) with tau=1/500. 

-Please run "exprb2s1.m" directly, and it will return "exprb2s1.mat", which contains 
--Energy2s1: the energy evolution;
--tmesh2s1: the corresponding times.

-We also provide the data in the folder.