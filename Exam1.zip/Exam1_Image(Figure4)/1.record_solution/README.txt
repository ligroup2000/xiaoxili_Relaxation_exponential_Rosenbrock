-The program codes in this folder are to record the numerical solutions from t=0 to t=15. 

-Please run "rexprb3s2.m" directly, and it will return "data.mat", which contains:
--U_save: the numerical solutions of U from t=0 to t=15;
--tmesh: the corresponding times.

-We also provide the data in the folder.