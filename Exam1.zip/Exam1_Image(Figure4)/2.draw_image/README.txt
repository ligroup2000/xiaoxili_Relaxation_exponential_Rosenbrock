-The program codes in this folder are to draw Figure 4.

-"data.mat" contains the numerical solutions from t=0 to t=15 and the corresponding times.

-Please run "draw_image_0_2.m" to draw the left subfigure in Figure 4.

-Please run "draw_image_8_10.m" to draw the right subfigure in Figure 4.

-We also provide the figures "image_kg1.eps" and "image_kg2.eps" in the folder.