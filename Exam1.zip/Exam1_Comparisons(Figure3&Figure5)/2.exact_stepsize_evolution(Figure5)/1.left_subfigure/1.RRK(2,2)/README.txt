-The program codes in this folder are to record the "exact" stepsizes by using RRK(2,2).

-Please run "main.m" directly, and it will return "data_rrk2s2.mat", which contains:
--exact_stepsize_rrk2s2_k: the "exact" stepsizes by using RRK(2,2) with time step tau=1/k;
--tmesh_rrk2s2_k: the corresponding times.

-We also provide the data in the folder.