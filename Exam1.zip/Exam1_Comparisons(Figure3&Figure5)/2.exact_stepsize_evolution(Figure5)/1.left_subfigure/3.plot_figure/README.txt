-The program codes in this folder are to plot the left subfigure in Figure 5. 

-"data_rrk2s2.mat" is copied from the previous folder "1.RRK(2,2)".

-"data_rexprb2s1.mat" is copied from the previous folder "2.RER(2,1)".

-Please run "plot_figure5_left.m" directly, and it will plot the "exact" stepsizes by using RRK(2,2) and RER(2,1) with different time steps.

-We also provide the figure "kg_RKRB2.eps" in the folder.