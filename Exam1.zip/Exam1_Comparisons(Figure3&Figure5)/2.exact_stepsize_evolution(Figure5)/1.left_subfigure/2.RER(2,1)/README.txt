-The program codes in this folder are to record the "exact" stepsizes by using RER(2,1).

-Please run "main.m" directly, and it will return "data_rexprb2s1.mat", which contains:
--exact_stepsize_rexprb2s1_k: the "exact" stepsizes by using RER(2,1) with time step tau=1/k;
--tmesh_rexprb2s1_k: the corresponding times.

-We also provide the data in the folder.