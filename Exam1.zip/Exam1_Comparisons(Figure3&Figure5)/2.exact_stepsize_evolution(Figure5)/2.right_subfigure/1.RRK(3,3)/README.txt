-The program codes in this folder are to present the "exact" stepsizes by using RRK(3,3) with large time steps.

-Please run the following codes in the Command Window (run one line at a time):
-- [exact_stepsize,tmesh]=rrk3s3(1/2);
-- [exact_stepsize,tmesh]=rrk3s3(1/4);
-- [exact_stepsize,tmesh]=rrk3s3(1/8);
