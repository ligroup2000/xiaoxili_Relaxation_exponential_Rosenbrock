-The program codes in this folder are to plot the right subfigure in Figure 5. 

-"data_rrk3s3.mat" is obtained by running the codes in the previous folder "1.RRK(3,3)".

-"data_rexprb3s2.mat" is copied from the previous folder "2.RER(3,2)".

-Please run "plot_figure5_right.m" directly, and it will plot the "exact" stepsizes by using RRK(3,3) and RER(3,2) with different time steps.

-We also provide the figure "kg_RKRB3.eps" in the folder.