-The program codes in this folder are to record the "exact" stepsizes by using RER(3,2) with large time steps.

-Please run "main.m" directly, and it will return "data_rexprb3s2.mat", which contains:
--exact_stepsize_rexprb3s2_k: the "exact" stepsizes by using RER(3,2) with time step tau=1/k;
--tmesh_rexprb3s2_k: the corresponding times.

-We also provide the data in the folder.