-The program codes in this folder are to draw Figure 3.

_"data_AVF.mat", "data_EAVF.mat", "data_csRK4.mat", "data_rexprb2s1.mat", "data_rexprb4s3.mat" are copied from the previous folders.

-Please run "draw_figure3.m" directly, and it will return the efficiency curves of the methods.

-We also provide the figure "efficiency_kg.eps" in the folder.