-The program codes in this folder are to compute the reference solution. 

-Please run "reference.m" directly, and it will return "reference.mat", which contains the reference solution 'Vn_c_1000' and 'Un_c_1000'.

-We also provide the data in the folder.