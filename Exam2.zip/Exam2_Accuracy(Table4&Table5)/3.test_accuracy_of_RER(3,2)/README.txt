-The program codes in this folder are to test the accuracy of RER(3,2). 

-"reference.mat" is copied from the previous folder "1.compute_reference_solution".

-Please run "main.m" directly, and it will return:
err =

   1.0e-05 *

   0.567345293722710   0.072481792834367   0.009164211545176   0.001152570217045


Err_order =

   2.968536499486132   2.983535973753557   2.991156116564063


Gamma_average_save =

   1.0e-04 *

   0.742002025112507   0.201433152258162   0.052444099670013   0.013376324276518


Gamma_average_order =

   1.881121979904718   1.941448770720516   1.971098741000527