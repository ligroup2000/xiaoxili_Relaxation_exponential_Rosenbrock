-The program codes in this folder are to test the accuracy of RER(4,3). 

-"reference.mat" is copied from the previous folder "1.compute_reference_solution".

-Please run "main.m" directly, and it will return:
err =

   1.0e-07 *

   0.436428044814363   0.025587583163400   0.001538613680907   0.000093653973465


Err_order =

   4.092228020712907   4.055740939573571   4.038147026200576


Gamma_average_save =

   1.0e-06 *

   0.452784512202761   0.050819693206725   0.005947051010876   0.000866033573395


Gamma_average_order =

   3.155365039536246   3.095141310407837   2.779679590602080