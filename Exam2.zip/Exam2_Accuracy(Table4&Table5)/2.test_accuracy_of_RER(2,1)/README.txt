-The program codes in this folder are to test the accuracy of RER(2,1). 

-"reference.mat" is copied from the previous folder "1.compute_reference_solution".

-Please run "main.m" directly, and it will return:
err =

   1.0e-03 *

   0.498093620432405   0.124161101240583   0.030972606220647   0.007733113426278


Err_order =

   2.004203674530795   2.003148568367736   2.001871505923232


Gamma_average_save =

   0.003455463578103   0.001775891131808   0.000900544652740   0.000453479414567


Gamma_average_order =

   0.960336130421941   0.979673424442784   0.989760750767910