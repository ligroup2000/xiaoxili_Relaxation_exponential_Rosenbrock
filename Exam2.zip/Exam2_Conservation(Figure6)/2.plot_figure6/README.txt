-The program codes in this folder are to plot Figure 6.

-data-10.mat: numerical results obtained from "exprb2s1.mat", "exprb3s2.mat", "exprb4s3.mat", "rexprb2s1.mat", "rexprb3s2.mat", "rexprb4s3.mat" in the previous folder.

-Please run "draw_energy.m" directly, and it will return the figure that records the evolutions of the energy discrepancies of the methods.

-We also provide the figure "energy_sg.eps" in the folder.