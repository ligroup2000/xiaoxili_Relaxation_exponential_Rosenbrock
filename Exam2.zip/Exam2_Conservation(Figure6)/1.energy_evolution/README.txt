-The program codes in this folder are to record the energy evolutions of the RER methods and the corresponding ER methods.

-exprb2s1.m: the code of ER(2,1), whose numerical results are saved in "exprb2s1_100.mat".

-exprb3s2.m: the code of ER(3,2), whose numerical results are saved in "exprb3s2_20.mat".

-exprb4s3.m: the code of ER(4,3), whose numerical results are saved in "exprb4s3_20.mat".

-rexprb2s1.m: the code of RER(2,1), whose numerical results are saved in "rexprb2s1_10.mat".

-rexprb3s2.m: the code of RER(3,2), whose numerical results are saved in "rexprb3s2_2.mat".

-rexprb4s3.m: the code of RER(4,3), whose numerical results are saved in "rexprb4s3_2.mat".
