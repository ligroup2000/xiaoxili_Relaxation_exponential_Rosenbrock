-The program codes in this folder are to plot Figure 7.

-"data-AVF.mat" are obtained from the codes in the folder "AVF".
 "data-EAVF.mat" are obtained from the codes in the folder "EAVF".
 "data-csRK4.mat" are obtained from the codes in the folder "csRK4".
 "data-rexprb2s1.mat" are obtained from the codes in the folder "RER21".
 "data-rexprb4s3.mat" are obtained from the codes in the folder "RER43".
 "data.mat" collects the data in "data-AVF.mat", "data-EAVF.mat", "data-csRK4.mat", "data-rexprb2s1.mat" and "data-rexprb4s3.mat".

-Please run "draw_efficiency.m" directly.

-We also provide the figure "efficiency_sg.eps" in the folder.