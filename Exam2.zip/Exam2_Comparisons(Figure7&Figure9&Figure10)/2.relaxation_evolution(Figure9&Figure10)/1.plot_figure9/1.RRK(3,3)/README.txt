-The program codes in this folder are to present the evolution of the relaxation parameters by using RRK(3,3) with tau=1/16.

-Please run the following codes in the Command Window: [GAMMA,tmesh]=rrk3s3(1/16);
