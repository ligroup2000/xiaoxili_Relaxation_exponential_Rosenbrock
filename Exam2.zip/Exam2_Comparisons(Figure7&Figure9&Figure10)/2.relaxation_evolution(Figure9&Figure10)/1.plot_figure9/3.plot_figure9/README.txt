-The program codes in this folder are to plot the left subfigure in Figure 9. 

-Please run "plot_sg_RKRB3.m" directly.