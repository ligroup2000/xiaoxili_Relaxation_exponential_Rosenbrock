-The program codes in this folder are to record the evolution of the relaxation parameters by using RER(3,2) with tau=1/16.

-Please run "rexprb3s2.m" directly, and it will return "data_rexprb3s2.mat", which contains:
--GAMMA: the relaxation parameters by using RER(3,2) with time step tau=1/16;
--tmesh: the corresponding times.

-We also provide the data in the folder.