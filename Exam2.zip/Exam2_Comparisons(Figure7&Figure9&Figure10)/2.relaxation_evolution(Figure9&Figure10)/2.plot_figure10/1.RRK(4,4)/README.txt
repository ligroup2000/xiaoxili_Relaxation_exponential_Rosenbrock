-The program codes in this folder are to present the evolution of the relaxation parameters by using RRK(4,4) with tau=1/4.

-Please run the following codes in the Command Window: [GAMMA,tmesh]=rrk4s4(1/4);
