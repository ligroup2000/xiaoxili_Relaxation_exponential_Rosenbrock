-The program codes in this folder are to record the evolution of the relaxation parameters by using RER(4,3) with tau=1/4.

-Please run "rexprb4s3.m" directly, and it will return "data_rexprb4s3.mat", which contains:
--GAMMA: the relaxation parameters by using RER(4,3) with time step tau=1/4;
--tmesh: the corresponding times.

-We also provide the data in the folder.