-The program codes in this folder are to plot the left subfigure in Figure 10. 

-Please run "plot_sg_RKRB4.m" directly.