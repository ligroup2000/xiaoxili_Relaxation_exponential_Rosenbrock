-The program codes in this folder are to plot Figure 8.

-"rexprb4s3.mat" is copied from the previous folder "Compute_image".

-Please run "draw_image.m" directly.

-We also provide the figure "image_sg.eps" in the folder.