-The program codes in this folder are to record the energy evolution of RER(4,3) with tau=1/4. 

-Please run "rexprb4s3.m" directly, and it will return "rexprb4s3.mat", which contains 
--Energyr4s3: the energy evolution;
--tmeshr4s3: the corresponding times.

-We also provide the data in the folder.