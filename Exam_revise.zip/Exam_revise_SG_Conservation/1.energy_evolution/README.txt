-The program codes in this folder are to record the energy evolutions of the RER methods.

-rexprb2s1.m: the code of RER(2,1), whose numerical results are saved in "rexprb2s1_50.mat".

-rexprb3s2.m: the code of RER(3,2), whose numerical results are saved in "rexprb3s2_45.mat".

-rexprb4s3.m: the code of RER(4,3), whose numerical results are saved in "rexprb4s3_20.mat".
