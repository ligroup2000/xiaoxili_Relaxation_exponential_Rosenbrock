-The program codes in this folder are to plot Figure energy_sg_revise.

-Please run "draw_energy.m" directly, and it will return the figure that records the evolutions of the energy discrepancies of the methods.

-We also provide the figure "energy_sg_revise.eps" in the folder.