-The program codes in this folder are to test the accuracy of RER(3,2). 

-"reference.mat" is copied from the previous folder "1.compute_reference_solution".

-Please run "main.m" directly, and it will return:
err =

   3.280684849460666   0.515716802995665   0.064269506323986   0.007974500412898   0.000993517606767


Err_order =

   2.669346054673825   3.004372756246465   3.010668345830414   3.004776699897166


Gamma_average_save =

   0.002154429974082   0.000525400875774   0.000130469856827   0.000032515978480   0.000008121319976


Gamma_average_order =

   2.035815696603346   2.009702073778842   2.004495787925988   2.001362702375565