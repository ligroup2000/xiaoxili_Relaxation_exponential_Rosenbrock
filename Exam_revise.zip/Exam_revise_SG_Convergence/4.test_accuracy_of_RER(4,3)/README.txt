-The program codes in this folder are to test the accuracy of RER(4,3). 

-"reference.mat" is copied from the previous folder "1.compute_reference_solution".

-Please run "main.m" directly, and it will return:
err =

   0.443361240842483   0.014541566695810   0.000443953395785   0.000013008037665   0.000000351339209


Err_order =

   4.930228036173250   5.033630665181665   5.092932991950560   5.210394939827772


Gamma_average_save =

   1.0e-04 *

   0.730353050126887   0.068838180552251   0.007963833930443   0.000979157187029   0.000121955348986


Gamma_average_order =

   3.407313154956446   3.111673924292667   3.023850753223184   3.005187442155000