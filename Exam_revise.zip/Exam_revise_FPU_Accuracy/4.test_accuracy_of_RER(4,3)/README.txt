-The program codes in this folder are to test the accuracy of RER(4,3). 

-"reference.mat" is copied from the previous folder "1.compute_reference_solution".

-Please run "main.m" directly, and it will return:
err =

   1.0e-05 *

   0.264746032963351   0.015460932508479   0.000924800367622   0.000056336406026


Err_order =

   4.097909825087178   4.063341554832672   4.037002536113149


Gamma_average_save =

   1.0e-06 *

   0.306426000061212   0.032723022724694   0.003947418624677   0.000490345531855


Gamma_average_order =

   3.227160788603012   3.051324589937959   3.009038888674754