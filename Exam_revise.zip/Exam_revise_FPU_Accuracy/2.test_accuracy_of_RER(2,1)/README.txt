-The program codes in this folder are to test the accuracy of RER(2,1). 

-"reference.mat" is copied from the previous folder "1.compute_reference_solution".

-Please run "main.m" directly, and it will return:
err =

   1.0e-03 *

   0.948032456929870   0.238906964774688   0.059607268715234   0.014864331686737


Err_order =

   1.988487539402057   2.002888739092645   2.003633668725508


Gamma_average_save =

   1.0e-04 *

   0.453793650029658   0.218980054780665   0.107353987403353   0.053367561060969


Gamma_average_order =

   1.051236949659105   1.028423694148618   1.008340791937847