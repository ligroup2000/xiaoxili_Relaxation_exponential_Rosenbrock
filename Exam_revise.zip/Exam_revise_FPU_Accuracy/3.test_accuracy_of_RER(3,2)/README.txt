-The program codes in this folder are to test the accuracy of RER(3,2). 

-"reference.mat" is copied from the previous folder "1.compute_reference_solution".

-Please run "main.m" directly, and it will return:
err =

   1.0e-04 *

   0.205492700400397   0.029736026439632   0.003931041231246   0.000503423471564


Err_order =

   2.788803365596543   2.919228475225737   2.965067108494801


Gamma_average_save =

   1.0e-05 *

   0.526827923757744   0.121376089970426   0.029763811495165   0.007435458286749


Gamma_average_order =

   2.117847564340165   2.027853059181755   2.001065715884373